
using Vintagestory.API.Common;

namespace RepairWorkbench
{
    public class BlockEntityRepairBench : BlockEntity
    {
    }
}
