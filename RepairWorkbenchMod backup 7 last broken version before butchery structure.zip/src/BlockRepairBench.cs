
using Vintagestory.API.Common;

namespace RepairWorkbench
{
    public class BlockRepairBench : Block
    {
    }
}
